import sys
import confuse
from azureml.core import Datastore, Dataset
from msrest.exceptions import HttpOperationError
import logging


class DataOPs:

    def __init__(self, ws):
        # YML configuration
        # Workspace
        self.workspace = ws
        # Datastore
        self.blob_datastore = self.workspace.get_default_datastore()
        # Dataset
        self.data_set = None
        self.logger = logging.getLogger(__name__)

    def __register_tabular(self, dataset_name, dataset_description):

        try:
            self.data_set = self.data_set.register(workspace=self.workspace,
                                                   name=dataset_name,
                                                   description=dataset_description,
                                                   tags={'format': 'parquet'},
                                                   create_new_version=True)
            print("Dataset registered")
        except Exception as ex:
            print(ex)

    def __register_file(self, dataset_name, dataset_description):
        try:
            self.data_set = self.data_set.register(workspace=self.workspace,
                                                   name=dataset_name,
                                                   description=dataset_description,
                                                   tags={'format': 'parquet'},
                                                   create_new_version=True)
            print("Dataset registered")
        except Exception as ex:
            print(ex)

    def register_dataset(self, blob_datastore_name, dataset_directory, dataset_file_name, dataset_name, dataset_description ,dataset_type="tabular"):

        try:
            self.blob_datastore = Datastore.get(self.workspace, blob_datastore_name)
            self.logger.info("Found blob datastore with name: %s" % blob_datastore_name)
        except HttpOperationError:
            self.logger.error("Unable to find blob datastore with name: %s" % blob_datastore_name)
            sys.exit()

        # Get and register dataset
        if dataset_type == "tabular":
            self.data_set = Dataset.Tabular.from_parquet_files(path=(
                self.blob_datastore, dataset_directory + '/' + dataset_file_name))
            self.__register_tabular(dataset_name=dataset_name, dataset_description=dataset_description)
        elif dataset_type == "file":
            self.data_set = Dataset.File.from_files(path=(self.blob_datastore, dataset_directory + '/' + dataset_file_name))
            self.__register_file(dataset_name=dataset_name, dataset_description=dataset_description)
        else:
            self.logger.error("Unsupported dataset type: %s" % dataset_type)
