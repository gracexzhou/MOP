import time
import logging
import confuse

from azureml.core.workspace import Workspace
from azureml.train.automl import AutoMLConfig
from azureml.core.dataset import Dataset
from azureml.data import TabularDataset
from azureml.core import ComputeTarget
from azureml.core.experiment import Experiment

from com.rogers.mlops.aml.explaining.MLExplain import MLExplain


class ModelCentricPipeline():

    def __init__(self, dsc, ws, training_data_name, label_col_name, task='classification', yaml_config_file="conf/pipeline.yaml"):
        """
        :param dsc: experiment description (str)
        :param ws: AzureML workspace (azureml.core.workspace.Workspace)
        :param training_data: string name of the training data on AzureML storage
        :param label_col_name: name (string) of the target column in the training dataset.
        """
        self.__experiment_description = dsc
        self.__workspace = ws
        self.__training_dataset_name = training_data_name
        self.__label_col_name = label_col_name
        self.__yaml_config_file = yaml_config_file
        self.__logger = logging.getLogger('ModelCentric')
        self.__logger.info('class initiated')
        self.__task = task
        self.__config = confuse.Configuration("ModelCentric", __name__)
        self.__config.set_file(yaml_config_file)
        conf_task = self.__config['pipeline']['model_centric'][self.task]
        self.aml_settings = (conf_task, conf_task['is_cross_validation'].get(bool))

    @property
    def experiment_description(self) -> str:
        return self.__experiment_description

    @property
    def workspace(self) -> Workspace:
        return self.__workspace

    @property
    def training_dataset_name(self) -> str:
        return self.__training_dataset_name

    @property
    def task(self) -> str:
        return self.__task

    @property
    def label_col_name(self) -> str:
        return self.__label_col_name

    @property
    def yaml_config_file(self) -> str:
        return self.__yaml_config_file

    @property
    def aml_settings(self):
        """
        get AutoML settings object to store AutoMLConfig parameters
        """
        return self.__aml_settings

    @aml_settings.setter
    def aml_settings(self, ct_cv):
        """
        set AutoML settings object to store AutoMLConfig parameters
        """
        try:
            conf_task, is_cross_validation = ct_cv
        except ValueError:
            self.__logger.exception("Please pass an iterable with two items")
            raise ValueError("Please pass an iterable with two items")
        else:
            orig_ds = Dataset.get_by_name(workspace=self.workspace, name=self.training_dataset_name)
            if is_cross_validation:
                self.__aml_settings = {"n_cross_validations": conf_task['n_cross_validations'].get(int),
                                       "training_data": orig_ds,
                                       "validation_data": None,
                                       }
            else:
                TabularDataset.random_split()
                train_ds, test_ds = orig_ds.random_split(percentage=conf_task['train_test_ratio'].get(float), seed=123)
                self.__aml_settings = {"n_cross_validations": None,
                                       "training_data": train_ds,
                                       "validation_data": test_ds,
                                       }

    def get_automl_config(self) -> AutoMLConfig:
        """
        automl_config is the configuration for submitting an automated ML experiment in Azure ML.
        This configuration object contains and persists the parameters for configuring the experiment run,
        as well as the training data to be used at run time. For guidance on selecting your settings, see https://aka.ms/AutoMLConfig.

        One way to specify an autoMLTraining configuration is to use specific configuration
        files such as YAML, accessible by the pipeline. This private function, to be used in
        the constructor, is to pass the autoML configurations from YAML to self.automl_config.

        :return: AutoMlConfig
        """
        conf_task = self.__config['pipeline']['model_centric'][self.task]

        return AutoMLConfig(
            task=self.task,
            iterations=conf_task['iterations'].get(int),
            primary_metric=conf_task['primary_metric'].get(str),
            allowed_models=conf_task['allowed_models'].get(list),
            label_column_name=self.label_col_name,
            experiment_timeout_minutes=conf_task['experiment_timout_minutes'].get(int),
            compute_target=ComputeTarget(workspace=self.workspace, name=conf_task['compute_target'].get(str)),
            verbosity=logging.INFO,
            enable_early_stopping=conf_task['enable_early_stopping'].get(bool),
            max_cores_per_iteration=8,
            max_concurrent_iterations=5,
            model_explainability=conf_task['model_explainability'].get(bool),
            **self.aml_settings
        )

    def execute(self, experiment_name, register_best_model=True, tags={}):
        """
        The main button that triggers the whole auto-ml training pipeline experiment to execute.
        :param experiment_name:
        :param register_best_model: A flag indicating if the best model out of the experiment should be registered in AzureML or not
        :param tags:
        :return:
        """

        experiment = Experiment(workspace=self.workspace, name=experiment_name)
        run = experiment.submit(config=self.get_automl_config(), show_output=True)
        run.wait_for_completion(show_output=True, wait_post_processing=True)

        # block until all child runs complete
        self.__logger.info('AutoML: Waiting for child runs to complete...')
        for child in run.get_children(recursive=True):
            while child.get_detailed_status().get('status') not in ['Completed', 'Failed', 'Canceled']:
                time.sleep(5)
            self.__logger.debug("\n<<< CHILD RUN details >>>\n %s", str(child.get_details()))
            child.wait_for_completion(show_output=True, wait_post_processing=True)
        self.__logger.info('AutoML: Child runs complete!')

        best_run, fitted_model = run.get_output()
        if register_best_model:
            run.register_model(description=self.experiment_description, tags=tags)

        # get explanations if model_explainability is True
        conf_task = self.__config['pipeline']['model_centric'][self.task]
        if conf_task['model_explainability'].get(bool):
            # 2. Get Feature Importance from run
            exp_auto_ml = MLExplain(fitted_model=fitted_model,
                                    yaml_config_file=self.yaml_config_file)
            explanations = exp_auto_ml.get_explanations(best_run)

        return run, best_run, fitted_model, explanations


