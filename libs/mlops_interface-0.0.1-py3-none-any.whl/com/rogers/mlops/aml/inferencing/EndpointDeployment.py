from com.rogers.mlops.aml.inferencing.EndpointPipeline import EndpointPipeline
from azureml.core import Model

"""
Changes:
    - One base class only (usage example like pytorch)
    - Inference Config / Deployment Config to be moved as internal operations in the Endpoint base class.
    - Create yaml / create script as internal configurable (path, libs, etc.) endpoint class functionalities.
    - no setters needed
    - comments for the class/functions
"""

class EndpointDeployment(EndpointPipeline):

    def __init__(self, ws, service_name, model, inference_config, deployment_config, service=None):
        """
        :param ws: AzureML workspace (azureml.core.workspace.Workspace)
        :param service_name: service name of endpoint
        :param model: model saved on AzureML storage (azureml.core.Model)
        :param inference_config: model saved on AzureML storage (azureml.core.model.InferenceConfig)
        :param deployment_config: model saved on AzureML storage (azureml.core.Model)
        """
        super().__init__()
        self.__workspace = ws
        self.__service_name = service_name
        self.__model = model
        self.__inference_config = inference_config
        self.__deployment_config = deployment_config
        self.__service = service

    @property
    def workspace(self):
        return self.__workspace

    @workspace.setter
    def workspace(self, ws):
        self.__workspace = ws

    @property
    def service_name(self):
        return self.__service_name

    @service_name.setter
    def service_name(self, service_name):
        self.__service_name = service_name

    @property
    def model(self):
        return self.__model

    @model.setter
    def model(self, model):
        self.__model = model

    @property
    def inference_config(self):
        return self.__inference_config

    @inference_config.setter
    def inference_config(self, inference_config):
        self.__inference_config = inference_config

    @property
    def deployment_config(self):
        return self.__deployment_config

    @deployment_config.setter
    def deployment_config(self, deployment_config):
        self.__deployment_config = deployment_config

    @property
    def service(self):
        return self.__service

    @service.setter
    def service(self, service):
        self.__service = service

    def execute(self):
        self.service = Model.deploy(self.workspace, self.service_name, [self.model],
                                    self.inference_config, self.deployment_config)
        self.service.wait_for_deployment(True)
        print(self.service.state)

    def delete(self):
        self.service.delete()
        print('Endpoint deleted.')
