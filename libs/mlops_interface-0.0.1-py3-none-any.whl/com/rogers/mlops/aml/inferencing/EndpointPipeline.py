import os
import confuse
from azureml.core import Model, Environment
from azureml.core.conda_dependencies import CondaDependencies
from azureml.core.webservice import AciWebservice
from azureml.core.model import InferenceConfig
from azureml.core.webservice import LocalWebservice


class EndpointPipeline:

    def __init__(self, ws, model, yml_config=None):
        """
        :param ws: AzureML workspace (azureml.core.workspace.Workspace)
        :param model: model name saved on AzureML storage
        :param yml_config: yml configuration containing inference and deployment settings
        """
        self.workspace = ws
        self.service_name = model.lower() + "-service"
        self.model = ws.models[model]
        self.inference_config = None
        self.deployment_config = None
        self.service = None
        self.yml_config = yml_config

        # If configuration does not exist, create default
        if self.yml_config is not None:
            # Get yml configuration
            self.yml_config = confuse.Configuration("inferenceConfig", __name__)
            self.yml_config.set_file(yml_config)

        # Create or retrieve inference and deployment configurations
        self._get_inference_config()
        self._get_deployment_config()

    def _get_inference_script(self, location):
        """
        Creates a default scoring script at the provided location.
        This function is not intended to be accessed outside as it is not part of the API.
        """

        # Current model retrieved is hard coded and needs to be changed
        with open(location, "w") as file:
            file.write("import json\nimport joblib\nimport numpy as np\nfrom "
                       "azureml.core.model import Model\n\n# Called when the service "
                       "is loaded\ndef init():\n    global model\n    # Get the path "
                       "to the deployed model file and load it\n    model_path = "
                       "Model.get_model_path('AutoML0441b8c8d2')\n    model = "
                       "joblib.load(model_path)\n\n# Called when a request is "
                       "received\ndef run(raw_data):\n    # Get the input data as a "
                       "numpy array\n    data = np.array(json.loads(raw_data)["
                       "'data'])\n    # Get a prediction from the model\n    "
                       "predictions = model.predict(data)\n    # Return the predictions\n    "
                       "return predictions\n")
        print("Saved scoring script in", location)

    def _get_inference_yml(self, location):
        """
        Creates a default yml file containing the environment and necessary dependencies
        required to run the model.
        This function is not intended to be accessed outside as it is not part of the API.
        """
        # Add the dependencies for model
        packages = CondaDependencies.create(conda_packages=self.yml_config['endpoint']['inference']['conda-dependencies'].get(list),
                                            pip_packages=self.yml_config['endpoint']['inference']['pip-dependencies'].get(list))

        # Write to yml
        with open(location, "w") as f:
            f.write(packages.serialize_to_string())
        print("Saved dependency info in", location)

    def _get_inference_config(self):
        """
        Creates the inference configuration utilized by the endpoint
        This function is not intended to be accessed outside as it is not part of the API.
        """
        # get runtime
        if self.yml_config is not None and self.yml_config['endpoint']['inference']['runtime'].get() is not None:
            runtime = self.yml_config['endpoint']['inference']['runtime'].get(str)
        else:
            runtime = "python"

        # get script
        if self.yml_config is not None and self.yml_config['endpoint']['inference']['script'].get() is not None:
            script = self.yml_config['endpoint']['inference']['script'].get(str)
        else:
            # Create folder to store configuration
            model_name = self.service_name.replace("-service", "")
            folder = './' + model_name + '_config'
            os.makedirs(folder, exist_ok=True)

            # Create scoring script
            script = os.path.join(folder, "score_" + model_name + ".py")
            self._get_inference_script(script)

        # get environment
        if self.yml_config is not None and self.yml_config['endpoint']['inference']['env'].get() is not None:
            env = self.yml_config['endpoint']['inference']['env'].get(str)
        else:
            # Create folder to store configuration
            model_name = self.service_name.replace("-service", "")
            folder = './' + model_name + '_config'
            os.makedirs(folder, exist_ok=True)

            # Create yml configuration
            env = os.path.join(folder, model_name + "_env.yml")
            self._get_inference_yml(env)

        self.inference_config = InferenceConfig(runtime=runtime,
                                                entry_script=script,
                                                conda_file=env)

    def _get_deployment_config(self):
        """
        Creates the deployment configuration utilized by the endpoint.
        Deployment configuration can be local, azure kubernetes service, azure container instance.
        This function is not intended to be accessed outside as it is not part of the API.
        """
        if self.yml_config is not None:
            webservice_type = self.yml_config['endpoint']['deployment']['webservice'].get(str).lower()
        else:
            webservice_type = "local"

        if webservice_type == "local":
            self.deployment_config = LocalWebservice.deploy_configuration(port=6789)
        elif webservice_type == "aci":
            self.deployment_config = AciWebservice.deploy_configuration(cpu_cores=1, memory_gb=1)

    def execute(self):
        """
        Main execute function that runs endpoint pipeline and deploys an endpoint.
        """
        self.service = Model.deploy(self.workspace, self.service_name, [self.model],
                                    self.inference_config, self.deployment_config)
        self.service.wait_for_deployment(True)
        print(self.service.state)

    def delete(self):
        """
        Function to delete the current active endpoint deployed by class
        """
        self.service.delete()
        print('Endpoint deleted.')
