from abc import ABC, abstractmethod, abstractproperty
from azureml.core import ComputeTarget
from azureml.core.workspace import Workspace
from azureml.core.dataset import  Dataset
from azureml.core.experiment import  Experiment
from azureml.train.automl import AutoMLConfig
import confuse
import logging


class AutoTrainingPipeline(ABC):

    """
        AutoTrainingPipeline is an abstract base class which provides a blue-print for various
        automated ML training classes. Automated ML training classes create objects that can configure and execute
        a fully automated ML training experiment pipeline on an AzureML workspace.
    """

    def __init__(self,yaml_config_file="conf/automl.yaml"):
        self.config = confuse.Configuration("AutoML", __name__)
        self.config.set_file(yaml_config_file)

    @abstractproperty
    def experiment_description(self) -> str:
        "simple natural language discription of the training experiment."
        pass

    @abstractproperty
    def task(self) -> str:
        " The ML task the automl training experiment is designed for: classification or regression "
        pass

    @abstractproperty
    def workspace(self) -> Workspace:
        """
        The base classes must define an Azure ML workspace to execute the automated ML experiment.
        :return:
            azureml.core.workspace.Workspace
            (https://docs.microsoft.com/en-us/python/api/azureml-core/azureml.core.workspace.workspace?view=azure-ml-py)
        """
        pass

    @abstractproperty
    def training_dataset_name(self) -> str:
        """
        Name (str) of the training dataset stored in an Azure datastore.
        """
        pass

    @abstractproperty
    def label_col_name(self) -> str:
        """
        Label (target) column name in the dataset.
        """
        pass

    def get_automl_config(self) -> AutoMLConfig:
        """
        automl_config is the configuration for submitting an automated ML experiment in Azure ML.
        This configuration object contains and persists the parameters for configuring the experiment run,
        as well as the training data to be used at run time. For guidance on selecting your settings, see https://aka.ms/AutoMLConfig.

        One way to specify an autoMLTraining configuration is to use specific configuration
        files such as YAML, accessible by the pipeline. This private function, to be used in
        the constructor, is to pass the autoML configurations from YAML to self.automl_config.

        :return: AutoMlConfig
        """

        return AutoMLConfig(
            task= self.task,
            iterations=self.config['training'][self.task]['iterations'].get(int),
            primary_metric=self.config['training'][self.task]['primary_metric'].get(str),
            allowed_models=self.config['training']['classification']['allowed_models'].get(list),
            training_data= Dataset.get_by_name(workspace=self.workspace, name = self.training_dataset_name),
            label_column_name=self.label_col_name,
            n_cross_validations= self.config['training'][self.task]['n_cross_validations'].get(int),
            experiment_timeout_minutes=self.config['training'][self.task]['experiment_timout_minutes'].get(int),
            compute_target=ComputeTarget(workspace=self.workspace,name=self.config['training'][self.task]['compute_target'].get(str)),
            verbosity=logging.INFO,
            enable_early_stopping= self.config['training'][self.task]['enable_early_stopping'].get(bool)
        )


    def execute(self, experiment_name, register_best_model = True, tags = {}):
        """
        The main button that triggers the whole auto-ml training pipeline experiment to execute.
        :param experiment_name:
        :param register_best_model: A flag indicating if the best model out of the experiment should be registered in AzureML or not
        :param tags:
        :return:
        """
        experiment = Experiment(workspace=self.workspace, name=experiment_name)
        run = experiment.submit(config=self.get_automl_config(), show_output=True)
        #run.wait_for_completion()
        best_run, fitted_model = run.get_output()
        if register_best_model:
            run.register_model(description=self.experiment_description, tags=tags)
        return best_run, fitted_model




