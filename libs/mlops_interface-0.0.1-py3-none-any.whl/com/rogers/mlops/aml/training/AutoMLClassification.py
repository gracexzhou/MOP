from com.rogers.mlops.aml.training import AutoTrainingPipeline


class AutoMlClassification(AutoTrainingPipeline):

    def __init__(self, dsc, ws, training_data_name, label_col_name):
        """
        :param dsc: experiment description (str)
        :param ws: AzureML workspace (azureml.core.workspace.Workspace)
        :param training_data: string name of the training data on AzureML storage
        :param label_col_name: name (string) of the target column in the training dataset.
        """
        super().__init__()
        self.__experiment_description = dsc
        self.__workspace = ws
        self.__training_dataset_name = training_data_name
        self.__label_col_name = label_col_name

    @property
    def experiment_description(self):
        return self.__experiment_description

    @property
    def workspace(self):
        return self.__workspace

    @property
    def training_dataset_name(self):
        return self.__training_dataset_name

    @property
    def task(self):
        return "classification"

    @property
    def label_col_name(self):
        return self.__label_col_name






