from com.rogers.mlops.aml.training import AutoTrainingPipeline


class AutoMlClassification(AutoTrainingPipeline):

    def __init__(self, dsc, ws, compute_target, training_data_name, label_col_name, task="classification", config={}):
        """
        :param dsc: experiment description (str)
        :param ws: AzureML workspace (azureml.core.workspace.Workspace)
        :param training_data: string name of the training data on AzureML storage
        :param label_col_name: name (string) of the target column in the training dataset.
        :param config: dict Configuration dictionary for automl
        """
        super().__init__()
        self.__compute_target = compute_target
        self.__experiment_description = dsc
        self.__workspace = ws
        self.__task = task
        self.__training_dataset_name = training_data_name
        self.__label_col_name = label_col_name
        self.__config = config

    @property
    def experiment_description(self):
        return self.__experiment_description

    @property
    def workspace(self):
        return self.__workspace

    @property
    def training_dataset_name(self):
        return self.__training_dataset_name

    @property
    def label_col_name(self):
        return self.__label_col_name

    @property
    def config(self) -> dict:
        return self.__config

    @property
    def compute_target(self) -> str:
        return self.__compute_target

    @property
    def task(self) -> str:
        return self.__task
