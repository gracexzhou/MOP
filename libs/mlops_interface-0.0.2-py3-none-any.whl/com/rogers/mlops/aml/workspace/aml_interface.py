from azureml.core import Workspace, Environment
import os
import logging
import confuse


class AMLObject:

    """
        AMLObject is the interface which enables the following communications
        between a given host (e.g. local host) and a remote AzureML workspace:
        - Connecting to a remote azure-ml workspace given input credentials
        - Connecting to a curated ML environment hosted on the remote aml workspace
        - (TBC)
    """

    def __init__(self, env=None):
        """
        Creating an instance of AMLObject which is connected to a remote azureML workspace.

        Credentials are read from .env file in the root directory. The .env file is included
        in the .gitignore, do NOT push it to any remote github repos.

        :param env: optional, a string representing a curated machine learning environment.
        """

        self.connected = False
        self.config = confuse.Configuration("AMLObject", __name__)
        self.config.set_file("conf/azure.yaml")
        self.ws = self.__aml_connect()
        self.env = None
        self.env_loaded = False
        if env!=None:
            self.env = self.__env_connect(env)


    def __aml_connect(self):
        """
        Connecting to a remote AML workspace..
        :return: WorkSpace if the connection is successfull, otherwise False
        """

        " Loading AzureML workspace credentials form the local .env file (root directory)"
        subscription_id = self.config["azureml"]["subscription_id"].get(str)
        resource_group = self.config["azureml"]["resource_group"].get(str)
        workspace_name = self.config["azureml"]["workspace_name"].get(str)

        try:
            ws = Workspace(subscription_id=subscription_id, resource_group=resource_group, workspace_name=workspace_name)
            ws.write_config()
            logging.info("Successfully connected to AzureML workspace.")
            self.connected = True
            return ws
        except Exception as e:
            logging.error("Unable to connect to AzureML workspace")
            logging.error(str(e))
            return None


    def __env_connect(self, env_name):
        """
        Private method, used in the constructor to load a curated azureml env.
        more information: https://docs.microsoft.com/en-us/azure/machine-learning/how-to-use-environments#use-a-curated-environment
        :param env_name: name of the azure_ml curated name to be loaded
        :return: an instance of azureml.core.Environment, or None if the connection is unsuccessful.
        """
        try:
            env = Environment.get(workspace=self.ws, name = env_name)
            logging.info("successfully connected to env {0}.".format(env_name))
            self.env_loaded = True
            return env
        except Exception as e:
            logging.error("unable to connect to env {0}.".format(env_name))
            logging.error(str(e))
            return None