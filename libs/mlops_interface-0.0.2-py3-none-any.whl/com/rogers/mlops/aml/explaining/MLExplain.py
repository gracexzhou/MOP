from azureml.core import Run
from azureml.interpret import ExplanationClient

from interpret.ext.blackbox import TabularExplainer
from interpret.ext.blackbox import MimicExplainer
from interpret.ext.blackbox import PFIExplainer

# Mimic explainers
from interpret.ext.glassbox import LGBMExplainableModel
from interpret.ext.glassbox import LinearExplainableModel
from interpret.ext.glassbox import SGDExplainableModel
from interpret.ext.glassbox import DecisionTreeExplainableModel

import logging
from pandas import DataFrame
import confuse


class MLExplain:

    """
        MLExplain class wraps explainers that are available in AzureML into one convenience class.
        First, explain the data by calling the explain_data method.
        If explanations have been created or are already available, get the explanations by calling the create_explanation method.

        https://docs.microsoft.com/en-us/azure/machine-learning/how-to-machine-learning-interpretability
        https://docs.microsoft.com/en-us/azure/machine-learning/how-to-machine-learning-interpretability-automl
        https://docs.microsoft.com/en-us/azure/machine-learning/how-to-machine-learning-interpretability-aml
    """

    def __init__(self, fitted_model, yaml_config_file="conf/explain.yaml"):
        """
        :param fitted_model: best model trained via AutoML or script
        :param yaml_config_file: YAML configuration file path containing explanation settings
        """
        self.config = confuse.Configuration("ExplainAutoML", __name__)
        self.config.set_file(yaml_config_file)
        self.__fitted_model = fitted_model
        self.__logger = logging.getLogger('MLExplain')
        self.__logger.info('class initiated')
        self.__tabular_explainer = None
        self.__mimic_explainer = None
        self.__pfi_explainer = None

    @property
    def fitted_model(self):
        """best or trained fitted model"""
        return self.__fitted_model

    def __get_tabular_explainer(self, X_train: DataFrame, features=None, label_names=None, explainable_model=None):
        """
        This method creates the tabular explainer and returns it.
        :param X_train: train dataset (Pandas dataframe) to perform explanations on.
                        NOTE: This must only contain the feature columns (without output prediction column)
        :param features: optional list of feature column names in the train dataset
        :param label_names: optional list of output label names in the original dataset
        :param explainable_model: Not used, only used for __get_mimic_explainer
        """
        if self.__tabular_explainer is None:
            self.__tabular_explainer = TabularExplainer(self.fitted_model, X_train,
                                                        features=features, classes=label_names)
        self.__logger.info('tabular explainer selected')
        return self.__tabular_explainer

    def __get_mimic_explainer(self, X_train: DataFrame, features=None, label_names=None, explainable_model=None):
        """
        This method creates the mimic explainer and returns it.
        :param X_train: train dataset (Pandas dataframe) to perform explanations on.
                        NOTE: This must only contain the feature columns (without output prediction column)
        :param features: optional list of feature column names in the train dataset
        :param label_names: optional list of output label names in the original dataset
        :param explainable_model: an explainable model to be used to explain the original model
        """
        if self.__mimic_explainer is None:
            self.__mimic_explainer = MimicExplainer(self.fitted_model, X_train, explainable_model,
                                                    augment_data=True, max_num_of_augmentations=10,
                                                    features=features, classes=label_names)
        self.__logger.info('mimic explainer selected')
        return self.__mimic_explainer

    def __get_pfi_explainer(self, X_train: DataFrame, features=None, label_names=None, explainable_model=None):
        """
        This method creates the PFI explainer and returns it.
        :param X_train: train dataset (Pandas dataframe) to perform explanations on.
                        NOTE: This must only contain the feature columns (without output prediction column)
        :param features: optional list of feature column names in the train dataset
        :param label_names: optional list of output label names in the original dataset
        :param explainable_model: Not used, only used for __get_mimic_explainer
        """
        if self.__pfi_explainer is None:
            self.__pfi_explainer = PFIExplainer(self.fitted_model, features=features, classes=label_names)
        self.__logger.info('pfi explainer selected')
        return self.__pfi_explainer

    def explain_data(self, run, X_train, y_train, X_test, explainer_type='tabular',
                           features=None, label_names=None, explainable_model_name:str=None):
        """
        Creates the requested explainer, runs the explanations, and uploads them to the corresponding Azure ML run.
        :param X_train: train dataset (Pandas dataframe) to perform explanations on.
                        NOTE: This must only contain the feature columns (without output prediction column)
        :param y_train: corresponding output column in the train dataset .
        :param X_test: test dataset (Pandas dataframe) to perform explanations on.
        :param explainer_type: one of 'tabular', 'mimic', 'pfi'
        :param features: optional list of feature column names in the train dataset
        :param label_names: optional list of output label names in the original dataset
        :param explainable_model_name: if explainer_type==='mimic', then must be one of 'lgbm', 'linear', 'sgd', 'decision tree'
        """
        if explainer_type not in ['tabular', 'mimic', 'pfi']:
            self.__logger.exception('explainer_type must be one of "tabular", "mimic" or "pfi"')
            raise ValueError('explainer_type must be one of "tabular", "mimic" or "pfi"')

        explainable_model = None
        # if explainer is mimic, check if it has a valid explainable_model name
        if explainer_type == 'mimic' and \
                (explainable_model_name is None or
                 explainable_model_name.lower() not in ['lgbm', 'linear', 'sgd', 'decision tree']):
            self.__logger.exception('explainer_type=mimic must be accompanied by valid explainable_model_name')
            raise ValueError('explainer_type=mimic must be accompanied by valid explainable_model_name')

        # set explainable_model if explainer is mimic
        if explainer_type == 'mimic':
            explainable_model = self.__explainable_models.get(explainable_model_name.lower())

        explainer = self.__explainers.get(explainer_type, self.__get_tabular_explainer)\
            (X_train, features, label_names, explainable_model)

        if explainer_type == 'pfi':
            global_explanation = explainer.explain_global(X_train, true_labels=y_train)
        else:
            global_explanation = explainer.explain_global(X_test)

        # get the Explanation Client from the run and upload the explanation
        explain_client = ExplanationClient.from_run(run)
        explain_client.upload_model_explanation(global_explanation, comment='Global and Local Explanations')

    @property
    def __explainable_models(self) -> dict:
        """dictionary of explainable models for mimic explainer"""
        return {
            'lgbm': LGBMExplainableModel,
            'linear': LinearExplainableModel,
            'sgd': SGDExplainableModel,
            'decision tree': DecisionTreeExplainableModel,
        }

    @property
    def __explainers(self) -> dict:
        """dictionary of explainer creation methods"""
        return {
            'tabular': self.__get_tabular_explainer,
            'mimic':   self.__get_mimic_explainer,
            'pfi':     self.__get_pfi_explainer,
        }

    def get_explanations(self, run: Run, is_raw=None):
        """
        Retrieves the explanations from the Azure ML run.
        :param run: Azure ML run object containing the explanations
        :param is_raw: gets the raw (raw=True) or engineered (raw=False) explanations.
        Set is_raw to True/False for script runs. Leave empty or set to None for AutoML runs.
        """
        # Instantiate the explanation client and get explanations
        explain_client = ExplanationClient.from_run(run=run)
        explanations_meta = explain_client.list_model_explanations()

        # list of dicts, each dict contains {metadata, feature impt, global impt names & values, [local impt names & values]}
        explanations = []
        for exp_meta in explanations_meta:
            exp_dict = {'metadata': exp_meta}

            # download the explanations
            explanation = explain_client.download_model_explanation(exp_meta.get('id'), raw=is_raw)
            if hasattr(explanation, 'get_feature_importance_dict'):  # global explanation
                # Get overall feature importance
                feature_importance = explanation.get_feature_importance_dict()
                exp_dict['feature importance'] = feature_importance

                # Get global Importance Values
                global_importance_names = explanation.get_ranked_global_names()
                global_importance_values = explanation.get_ranked_global_values()
                exp_dict['global importance names'] = global_importance_names
                exp_dict['global importance values'] = global_importance_values

            if hasattr(explanation, 'get_ranked_local_names'):
                # Get ranked local values
                local_importance_names = explanation.get_ranked_local_names()
                local_importance_values = explanation.get_ranked_local_values()
                exp_dict['local importance names'] = local_importance_names
                exp_dict['local importance values'] = local_importance_values

            explanations.append(exp_dict)

        return explanations




